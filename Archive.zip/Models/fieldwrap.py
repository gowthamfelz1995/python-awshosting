class field_wrap_obj:
    def __init__(self, fieldName, isExists):
        self.fieldName = fieldName
        self.isExists = isExists
   