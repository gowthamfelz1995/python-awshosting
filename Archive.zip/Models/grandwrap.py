class grand_wrap_obj:
    def __init__(self, objName, isExists, fieldWrapperList):
        self.objName = objName
        self.isExists = isExists
        self.fieldWrapperList = fieldWrapperList
   