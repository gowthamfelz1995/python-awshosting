class parent_wrap_obj:
    def __init__(self, objName, isExists, fieldWrapperList, childObjWrapperList, parentObjWrapperList, grandObjWrapperList):
        self.objName = objName
        self.isExists = isExists
        self.fieldWrapperList = fieldWrapperList
        self.childObjWrapperList = childObjWrapperList
        self.parentObjWrapperList = parentObjWrapperList
        self.grandObjWrapperList = grandObjWrapperList
