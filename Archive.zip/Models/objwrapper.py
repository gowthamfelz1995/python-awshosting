class obj_wrap:
    def __init__(self, objName, isExists, fieldWrapperList, childObjWrapperList, parentObjWrapperList):
        self.objName = objName
        self.isExists = isExists
        self.fieldWrapperList = fieldWrapperList
        self.childObjWrapperList = childObjWrapperList
        self.parentObjWrapperList = parentObjWrapperList

 